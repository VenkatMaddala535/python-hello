"""Run the local learning server."""

import os

from hello_web.app import create_app


def main():
    create_app().run(
        host=os.environ.get("HOST", "127.0.0.1"),
        port=int(os.environ.get("PORT", "5000")),
        debug=False,
    )


if __name__ == "__main__":
    main()
